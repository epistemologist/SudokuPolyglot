select 1 as i_, * f
m digits as n1, ..., n81 
    if (p logic) 
    where p = (select * from puzzle where i_ = i) 
    union all 
    select i_+1, n1, ..., n81 from solved_puzzle 
    where i_<50
